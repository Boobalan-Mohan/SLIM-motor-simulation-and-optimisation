# COMSOL Simulation Parameters

All electromagnetic simulations were performed in **COMSOL Multiphysics** using the AC/DC module with time-domain transient analysis. The motor geometry was fully parameterized to allow sweep studies across frequency, slip, and current.

---

## Base Design Parameters

| Parameter | Symbol | Expression | Value |
|---|---|---|---|
| Aluminum track thickness | Al_ht | 6 mm | 0.006 m |
| Aluminum track length | Al_l | 7000 mm | 7 m |
| Slot width | slot_w | 8.33 mm | 0.00833 m |
| Tooth width | tooth_w | 8.33 mm | 0.00833 m |
| Number of slots | n_s | 28 | 28 |
| Number of teeth | n_t | n_s + 1 | 29 |
| Air gap | air_gap | 6 mm | 0.006 m |
| Yoke height | yoke_ht | 20 mm | 0.02 m |
| Slot height | slot_ht | 47.73 mm | 0.04773 m |
| Tooth height | tooth_ht | 47.73 mm | 0.04773 m |
| Yoke length | yoke_l | n_t × tooth_w + n_s × slot_w | 0.47481 m |

---

## Electrical Drive Parameters

| Parameter | Symbol | Expression | Value |
|---|---|---|---|
| Drive frequency (base) | f0 | 30 Hz | 30 Hz |
| Drive current (base) | I0 | 100 A | 100 A |
| Initial track velocity | v0 | 1.8 m/s | 1.8 m/s |
| Short pitch factor | k | 2/3 | 0.66667 |
| Turns per coil | nc | 72 | 72 |

---

## Derived Motor Parameters

| Parameter | Symbol | Expression | Value |
|---|---|---|---|
| Pole pitch (full) | p | 4 × (slot_w + tooth_w) | 0.06664 m |
| Pole pitch | pp | 0.102 m | 0.102 m |
| Synchronous velocity | synV | 2 × pp × f0 | 6.12 m/s |
| Slip (base case) | slip | 0.2 | 0.2 |
| Track velocity (base) | v | synV × (1 − slip) | 5 m/s |

---

## Parametric Sweep Summary

| Study | Variable swept | Fixed conditions | Output |
|---|---|---|---|
| Frequency sweep | 25, 35, 45, 55, 65 Hz | I = 100 A, v₀ = 5 m/s | Thrust & normal force |
| Slip sweep (35 Hz, 80 A) | slip = 0 to 0.5 (step 0.05) | f = 35 Hz, I = 80 A | Thrust & normal force |
| Slip sweep (45 Hz, 80 A) | slip = 0 to 0.5 (step 0.05) | f = 45 Hz, I = 80 A | Thrust & normal force |
| Slip sweep (35 Hz, 100 A) | slip = 0 to 0.5 (step 0.05) | f = 35 Hz, I = 100 A | Thrust & normal force |
| Slip sweep (45 Hz, 100 A) | slip = 0 to 0.5 (step 0.05) | f = 45 Hz, I = 100 A | Thrust & normal force |
| Current sweep (35 Hz) | I = 85, 90, 95 A | f = 35 Hz, slip = 0.299 | Thrust & normal force |
| Current sweep (45 Hz) | I = 85, 90, 95 A | f = 45 Hz, slip = 0.455 | Thrust & normal force |
| Current sweep (55 Hz) | I = 85, 90, 95 A | f = 55 Hz, slip = 0.554 | Thrust & normal force |
| Current sweep (65 Hz) | I = 85, 90, 95 A | f = 65 Hz, slip = 0.622 | Thrust & normal force |
| Startup transient | — | slip = 1 (v = 0), I = 80 A | Force vs. time from standstill |

---

## Notes on Force Sign Convention

- **x-component (thrust):** Propulsive force along the direction of motion. Negative values in COMSOL indicate force in the direction of motion (convention artifact — magnitude is what matters).
- **y-component (normal/levitation):** Force perpendicular to the track surface. Negative values indicate attraction toward the track (SLIM generates attractive normal force, not repulsive levitation).

> In SLIM topology, the normal force is **attractive** (the primary is pulled toward the secondary), unlike EMS maglev which uses active control to maintain gap. This must be accounted for in the mechanical suspension design.
