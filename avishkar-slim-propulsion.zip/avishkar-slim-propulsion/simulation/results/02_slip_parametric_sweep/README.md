# Slip Parametric Sweep

**Purpose:** Understand how thrust and normal force vary with slip across different operating points.  
**Slip range:** 0 to 0.5 in steps of 0.05 (11 values per case)  
**Cases tested:** 4 combinations of frequency (35 Hz, 45 Hz) × current (80 A, 100 A)

> **What is slip?**  
> Slip = (synchronous velocity − track velocity) / synchronous velocity.  
> Slip = 1 means the track is stationary (full startup). Slip = 0 means the track moves at the same speed as the magnetic field (no force generated). The motor operates somewhere in between.

---

## Case 1: 35 Hz, 80 A

### Thrust (x-component)
![35Hz 80A Thrust vs Slip](35Hz_80A_thrust_x_vs_slip.jpg)

### Normal Force (y-component)
![35Hz 80A Normal Force vs Slip](35Hz_80A_normal_y_vs_slip.jpg)

**Observation:** At 35 Hz and 80 A, thrust increases as slip increases from 0, peaks around slip = 0.25–0.35, then plateaus. Higher slip values (0.4–0.5) show converging behavior — the motor is approaching breakdown torque equivalent.

---

## Case 2: 45 Hz, 80 A

### Thrust (x-component)
![45Hz 80A Thrust vs Slip](45Hz_80A_thrust_x_vs_slip.jpg)

### Normal Force (y-component)
![45Hz 80A Normal Force vs Slip](45Hz_80A_normal_y_vs_slip.jpg)

**Observation:** At 45 Hz, the thrust magnitude is noticeably lower than 35 Hz at the same current. The normal force also reduces — confirming that 35 Hz is the better operating point for this geometry.

---

## Case 3: 35 Hz, 100 A

### Thrust (x-component)
![35Hz 100A Thrust vs Slip](35Hz_100A_thrust_x_vs_slip.jpg)

### Normal Force (y-component)
![35Hz 100A Normal Force vs Slip](35Hz_100A_normal_y_vs_slip.jpg)

**Observation:** Increasing current from 80 A to 100 A at 35 Hz significantly boosts both thrust and normal force (roughly proportional to I²). The spread between slip values also increases, giving more control authority.

---

## Case 4: 45 Hz, 100 A

### Thrust (x-component)
![45Hz 100A Thrust vs Slip](45Hz_100A_thrust_x_vs_slip.jpg)

### Normal Force (y-component)
![45Hz 100A Normal Force vs Slip](45Hz_100A_normal_y_vs_slip.jpg)

**Observation:** 45 Hz at 100 A approaches the performance of 35 Hz at 80 A — demonstrating the trade-off between frequency and current for achieving target force levels.

---

## Summary

| Case | Peak Thrust (approx.) | Peak Normal Force (approx.) |
|---|---|---|
| 35 Hz, 80 A | ~2,800 N | ~3,200 N |
| 45 Hz, 80 A | ~2,400 N | ~3,000 N |
| 35 Hz, 100 A | ~4,000 N | ~5,000 N |
| 45 Hz, 100 A | ~3,500 N | ~4,400 N |

**Key takeaway:** For a given current, lower frequency (within the optimal range) consistently produces higher force. For a given frequency, higher current produces higher force but at the cost of inverter capacity and thermal loading.
