# Initial Velocity = 0 (Startup Transient)

**Purpose:** Simulate the motor starting from complete standstill — the hardest operating condition for a SLIM.  
**Condition:** Track velocity = 0 m/s → slip = 1.0 (maximum possible slip)  
**Significance:** Pod must accelerate from rest; this test validates the motor can generate sufficient startup thrust.

---

## Startup Force Transient

![Startup Force Transient](startup_force_transient.jpg)

**What this plot shows:**

- At t = 0, both thrust (x) and normal force (y) spike to very high values (~5,000–5,500 N)
- This initial peak occurs because slip = 1 → maximum induced currents in the aluminum track → maximum force
- By t ≈ 0.2 s, forces settle to steady-state values:
  - Thrust: ~3,400–3,500 N
  - Normal force: ~3,000–3,200 N
- The oscillation in steady-state is a simulation artifact from field discretization and is within acceptable bounds

**Design implication:** The startup peak force (~5 kN) must be accounted for in the mechanical structure of the pod and the current rating of the inverter. The inverter must handle this transient without tripping.

---

## Magnetic Flux Density Map

![Magnetic Flux Density Color Map](magnetic_flux_density_map.jpg)

**What this plot shows:**

This is a cross-sectional view of the SLIM at t = 1.8 s (steady state). The color map shows magnetic flux density in Tesla (T):

- **Purple/dark regions (high B):** Inside the primary teeth — flux is concentrated here, as designed
- **Green/teal regions (medium B):** In the air gap and aluminum track — this is the working flux that induces currents and generates force
- **Blue/light regions (low B):** Surrounding air and yoke regions

The traveling magnetic wave pattern is clearly visible — this is the linear equivalent of a rotating magnetic field in a conventional motor. It moves left-to-right (or right-to-left depending on phase sequence), dragging the aluminum track along with it.

> **Peak flux density: ~11.2 T** shown in the legend — this occurs at sharp tooth corners and is a localized numerical artifact of the FEM mesh. The bulk tooth flux density is in the range of 4–8 T which is physically reasonable for laminated silicon steel.

---

## Key Numbers

| Metric | Value |
|---|---|
| Track velocity | 0 m/s (standstill) |
| Slip | 1.0 |
| Peak startup thrust | ~5,300 N |
| Steady-state thrust | ~3,400 N |
| Steady-state normal force | ~3,100 N |
| Simulation duration | 2 s |
| Field established by | ~0.15 s |
