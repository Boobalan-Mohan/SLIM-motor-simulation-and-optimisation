# Preliminary Results — Frequency Sweep

**Simulation condition:** Initial track velocity = 5 m/s, Drive current = 100 A, Pole pitch = 0.102 m  
**Frequencies tested:** 25 Hz, 35 Hz, 45 Hz, 55 Hz, 65 Hz  
**Tool:** COMSOL Multiphysics (AC/DC module, transient analysis)

---

## SLIM Model (COMSOL Geometry)

![SLIM Model Render](slim_model_render.jpg)

The primary (top block with colored coil slots) sits above the aluminum secondary track. The air gap between them is 6 mm.

---

## Design Parameters Used

![Design Parameters Table](design_parameters_table.jpg)

See [`simulation/parameters.md`](../../parameters.md) for the full parameter table with descriptions.

---

## Thrust Force (x-component) — 5 Frequencies

![Thrust Force vs Frequency](thrust_force_vs_frequency.jpg)

- **35 Hz produces the highest thrust** among all tested frequencies
- Force settles to steady state within ~0.2–0.3 s of simulation time
- Higher frequencies (55–65 Hz) produce significantly lower thrust at this pole pitch
- The transient peak at t ≈ 0.1 s is due to initial field establishment

---

## Normal Force (y-component) — 5 Frequencies

![Normal Force vs Frequency](normal_force_vs_frequency.jpg)

- Normal force is **attractive** (negative y = pulled toward track)
- 35 Hz again yields the highest magnitude normal force (~4,400 N)
- Normal force saturates faster than thrust — useful for suspension design

---

## Conclusion

| Frequency | Slip | Relative Thrust | Relative Normal Force |
|---|---|---|---|
| 25 Hz | — | Moderate | Moderate |
| **35 Hz** | **0.299** | **Maximum** | **Maximum** |
| 45 Hz | 0.455 | High | High |
| 55 Hz | 0.554 | Medium | Medium |
| 65 Hz | 0.622 | Low | Low |

**35 Hz is the optimal operating frequency** for this motor geometry (pole pitch = 0.102 m, I = 100 A, v = 5 m/s).

> At higher frequencies, synchronous velocity increases, which reduces slip for the same track speed, lowering both thrust and normal force. This follows classical linear induction motor slip-force theory.
