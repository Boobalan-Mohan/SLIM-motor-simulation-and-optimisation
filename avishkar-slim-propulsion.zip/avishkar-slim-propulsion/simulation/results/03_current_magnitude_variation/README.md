# Current Magnitude Variation

**Purpose:** Quantify how increasing drive current affects thrust and normal force at different operating frequencies.  
**Baseline:** 80 A across all frequencies  
**Sweep:** 85 A, 90 A, 95 A at each frequency  
**Frequencies tested:** 35 Hz, 45 Hz, 55 Hz, 65 Hz  

> Slip values used in this study were derived from the preliminary frequency sweep — each frequency was run at its naturally corresponding slip for a 5 m/s track velocity.

---

## Baseline: 80 A Across Frequencies

### Thrust (x) and Normal Force (y) — 80 A

![80A Thrust vs Frequency](80A_thrust_x_vs_freq.jpg)
![80A Normal Force vs Frequency](80A_normal_y_vs_freq.jpg)

These plots confirm the baseline behavior: 35 Hz dominates.

---

## 35 Hz — Current Sweep (Slip = 0.299)

### Normal Force
![35Hz 85-95A Normal Force](35Hz_85to95A_normal_y.jpg)

### Thrust
![35Hz 85-95A Thrust](35Hz_85to95A_thrust_x.jpg)

**Observation:** At 35 Hz (slip = 0.299), increasing current from 85 A → 95 A produces a clear and consistent increase in both thrust and normal force. The curves are well-separated, indicating good control sensitivity in this range.

---

## 45 Hz — Current Sweep (Slip = 0.455)

### Thrust
![45Hz 85-95A Thrust](45Hz_85to95A_thrust_x.jpg)

### Normal Force
![45Hz 85-95A Normal Force](45Hz_85to95A_normal_y.jpg)

**Observation:** At 45 Hz, the force gain per ampere is lower than at 35 Hz. The higher slip at 45 Hz means the motor is operating further from its peak efficiency point.

---

## 55 Hz — Current Sweep (Slip = 0.554)

![55Hz Overview](55Hz_85to95A_overview.jpg)

**Observation:** At 55 Hz, the thrust curves are more closely bunched — diminishing returns from increasing current become visible. The high slip (0.554) indicates the motor is being driven hard at a suboptimal frequency.

---

## 65 Hz — Current Sweep (Slip = 0.622)

### Thrust
![65Hz 85-95A Thrust](65Hz_85to95A_thrust_x.jpg)

### Normal Force
![65Hz 85-95A Normal Force](65Hz_85to95A_normal_y.jpg)

**Observation:** At 65 Hz, force levels are the lowest across all current levels tested. The slip (0.622) is very high, meaning the track speed is far below synchronous speed — this is a very inefficient operating region.

---

## Summary Table

| Frequency | Slip | Force sensitivity to current |
|---|---|---|
| 35 Hz | 0.299 | High — well-separated curves |
| 45 Hz | 0.455 | Moderate |
| 55 Hz | 0.554 | Reducing — curves converge |
| 65 Hz | 0.622 | Low — diminishing returns |

**Design implication:** Current magnitude is most effective as a control variable at 35 Hz where the motor operates near its optimal slip. At higher frequencies, the frequency itself is the dominant variable — no amount of current increase fully compensates for operating at the wrong frequency.
