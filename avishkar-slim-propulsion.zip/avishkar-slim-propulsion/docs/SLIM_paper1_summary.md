# SLIM Design Parameters — Paper 1 Summary

Literature notes from an optimization study on a low-speed Single-Sided Linear Induction Motor for rail transit.

**Paper link:** Not publicly available. Contact the team for access.

---

## Vehicle Context

This paper targets a **low-speed SLIM** with:
- Proposed max speed: **70 km/h**
- Vehicle dimensions: 12 m length × 2.45 m wide × 2.95 m high
- Vehicle weight: **21 tonnes**

---

## Optimization Framework

| Aspect | Method |
|---|---|
| Main considerations | Motor weight, cost of secondary materials, energy consumption |
| Performance analysis | Space Harmonic Analysis |
| Optimization method | Non-linear programming using **SUMT** (Sequential Unconstrained Minimization Technique) |
| Constraint functions | Output kW/Input kVA, max flux density in teeth, temperature rise, primary length |

---

## Drive System

- SLIM driven by a **Variable Voltage Variable Frequency (VVVF) inverter**
- **Below rated speed:** Constant V/Hz (volts-per-hertz) control
- **Above rated speed:** Constant voltage control

> This is the same fundamental control philosophy as standard industrial VFDs, adapted for linear topology.

---

## Key Design Relationships

### 1. Rated Speed
- Performance improves with increasing rated speed
- Penalty: primary current (kVA) and motor weight both increase
- Hard limit: current capacity of VVVF inverters and GTO (Gate Turn-Off) thyristors

### 2. Thrust Ratio (Fm/Fn)
- Fm = peak thrust, Fn = rated thrust
- Suitable range: **1.5 to 2.5**
- Higher ratio → lower energy consumption, higher core weight, better power factor
- Thrust drops **gradually** (not sharply) as slip decreases

### 3. Primary Length
- Optimal at ~**2 m** for minimum kVA
- Longer primary → reduced end effects
- Can vary L while keeping `L × h` constant to hold flux density steady

### 4. Pole Pitch (τ)
- Frequency and pole count are **inversely proportional** to τ
- Motor weight decreases with smaller τ
- Below **200 mm**: performance drops significantly
- **Optimal range: 250–350 mm**

### 5. Efficiency Metric
- kW/kVA ratio ≈ power factor × efficiency
- Maximum achievable: ~**40%**

### 6. Winding
- **Double layer, distributed, short-pitch winding**
- Slots per pole per phase: **3 to 6**
- Coil pitch: **0.65 to 0.85**
- More slots → higher manufacturing cost (more coils, smaller slot pitch)

### 7. Slot Geometry
- Increasing Ws/Ts (slot width / slot pitch ratio):
  - Reduces slot leakage reactance ✓
  - Increases max flux density in teeth ✗
  - Increases equivalent air gap length

### 8. Aluminum Track (Secondary)
- Minimum aluminum thickness (d2): **5 mm**
- Below 5 mm → energy consumption rises sharply
- Secondary resistance increases as lateral track extension (c) decreases

### 9. Air Gap
- Air gap has a **large effect** on both kVA demand and motor weight
- Minimizing air gap improves efficiency but increases manufacturing precision requirements
