# SLIM Design Notes

Key design principles compiled from literature review, primarily based on IEEE reference [5535183](https://ieeexplore.ieee.org/document/5535183).

---

## Pole Configuration

- **4-pole motor** is the best compromise for a test/lab setup
  - 2-pole: severe end effects degrade performance
  - 6-pole: physically too large for pod-scale application
- A four-pole configuration balances end-effect suppression with manageable motor length

## Air Gap & Clearance

- Chosen clearance gap (physical distance between primary core and aluminum track): **18.2 mm**
- Chosen slip at design point: **0.24**
- Air gap flux density should be **low**
- Tooth flux density should also be **low**
- Current loading should be **high**

> **What is clearance gap?** The physical distance between the face of the primary (the coil-carrying laminated core on the pod) and the surface of the secondary (the aluminum reaction rail on the track). It includes the actual electromagnetic air gap plus any structural/mechanical tolerances. Larger clearance reduces force but allows physical tolerance for track irregularities.

## Pole Pitch (τ)

- Frequency and number of poles are **inversely proportional** to pole pitch
- Primary and secondary weight **decreases with decreasing τ**
- Pole pitch < 200 mm → performance reduces remarkably
- **Suitable pole pitch range: 250 mm to 350 mm**
- An increase in pole pitch improves machine performance generally

## Slot & Tooth Geometry

- **Best slot-to-tooth ratio: 3:2** (wide slot)
  - Wide slots → lower slot leakage flux
  - Wide slots → increased current loading capability
- Decreasing tooth height → thrust increases
- Ratio of slot width (Ws) to slot pitch (Ts) increasing:
  - Slot leakage reactance decreases (good)
  - Max flux density in teeth increases (must be managed)
  - Equivalent air gap length increases

## Secondary (Aluminum Track) Parameters

- Decreasing aluminum track thickness (d2) below **5 mm** → energy consumption increases sharply
- Secondary resistance increases as the track extension outside primary width (c) decreases
- Air gap has a **large effect on kVA and motor weight**

## Winding Configuration

- Type: **Double layer, distributed, short-pitch winding**
- Slots per pole per phase: **3 to 6**
- Coil pitch factor: **0.65 to 0.85**
- More slots → smaller slot pitch → increased manufacturing cost (more coils)

## Primary Length

- Primary length of **2 m** gives minimum kVA (most efficient from an apparent power perspective)
- Longer primary reduces end effects
- L can be varied while keeping `L × h` (primary surface area) constant to maintain constant flux density

## Performance Scaling

- Performance improves with increasing rated speed
- But: primary current (kVA) and motor weight also increase
- Upper limit set by: current capacity of VVVF inverters and GTO thyristors
- kW/kVA ratio (equivalent to power factor × efficiency): max ~40%

## Thrust-to-Rated Force Ratio (Fm/Fn)

- Fm = Maximum thrust, Fn = Rated thrust
- Increasing Fm/Fn (above 1.5):
  - Energy consumption decreases
  - Primary core weight increases
  - Power factor increases (rated slip decreases)
- **Suitable Fm/Fn range: 1.5 to 2.5**
- Thrust drops gradually with decreasing slip (not abruptly)
