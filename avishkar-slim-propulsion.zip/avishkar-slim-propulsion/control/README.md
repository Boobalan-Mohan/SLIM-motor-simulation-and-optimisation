# PMSM Field-Oriented Control (FOC) — Design

**Purpose:** Design and implement a Field-Oriented Control (FOC) strategy in MATLAB/Simulink for the Permanent Magnet Synchronous Motor (PMSM) that drives the SLIM inverter.  
**Tool:** MATLAB Simulink  
**Status:** Design completed, Simulink model implemented and validated for torque-speed characteristics.

---

## What is FOC and Why Does It Matter Here?

A PMSM is a high-efficiency motor used to drive the 3-phase inverter that feeds the SLIM. Without proper control, a PMSM produces oscillating, inefficient torque. FOC "decouples" the motor's magnetic flux from its torque — so you can control them independently, just like a DC motor. This gives fast, precise torque response which is critical for controlling the pod's acceleration profile.

> **Analogy:** Think of it like steering and throttle in a car being independent controls. Without FOC, they're tangled together. With FOC, they're separate — you get full control authority.

---

## FOC Implementation Flowchart

![PMSM FOC Flowchart](pmsm_foc_flowchart.jpg)

---

## Implementation Steps (from Flowchart)

### Stage 1 — Motor Modeling
1. Derive the **DQ mathematical model** of the PMSM
   - Transforms 3-phase (abc) quantities into a 2-axis (d-q) rotating reference frame
   - Dramatically simplifies the math — AC quantities become DC quantities in the rotating frame
2. Build the **DQ equivalent circuit** in Simulink
3. Validate: check that the Simulink PMSM model produces correct torque-speed behavior

### Stage 2 — Controller Design
4. Design **motor torque block** and torque-to-speed conversion
5. Implement **Park Transform** (abc → dq) and **Inverse Park Transform** (dq → abc)
6. Design **PI Controller 1:** Holds Id = 0 (zero d-axis current = maximum torque per ampere operation)
7. Design **PI Controller 2:** Estimates required torque from reference speed error
8. Design **converter block:** Calculates Iq command from torque reference

### Stage 3 — Inverter & Integration
9. Assemble the complete **FOC block** from all sub-blocks above
10. Design **PWM comparator-based inverter model** in Simulink
11. Combine PMSM model + FOC + Inverter → complete closed-loop drive system

### Stage 4 — Optimization
12. Tune PI controller gains by varying motor parameters
13. Validate until target **torque-speed curves** are achieved

---

## Control Strategy Summary

| Parameter | Approach |
|---|---|
| d-axis current (Id) | Held at 0 A (maximum torque per ampere) |
| q-axis current (Iq) | Commanded from torque reference |
| Speed loop | PI controller |
| Current loop | PI controller (inner loop) |
| Reference frame | Rotor-field oriented (synchronous frame) |
| Modulation | PWM comparator-based |

---

## Relation to SLIM Control

The PMSM + FOC system controls the mechanical power input to the SLIM inverter. The SLIM itself is controlled through the inverter's output frequency and voltage (VVVF control). Together, the two systems form a cascaded control architecture:

```
Speed reference
      ↓
  FOC (PMSM)          ← inner loop: fast current control
      ↓
  VVVF Inverter       ← middle loop: frequency & voltage control
      ↓
  SLIM (propulsion)   ← outer behavior: pod thrust & velocity
```
